#!/usr/bin/python

import sqlite3

conn = sqlite3.connect('wa.db')
print "Opened database successfully";

cursor = conn.execute("SELECT display_name,number,status,status_timestamp, thumb_ts,given_name,family_name,wa_name,sort_name,nickname  from wa_contacts")
for row in cursor:
   print "Display name = ", row[0]
   print "Number", row[1]
   print "Status = ", row[2]
   print "Status timestamp =",row[3]
   print "Time at which contact set his/her picture:",row[4]
   print "given_name",row[5]
   print "family_name",row[6]
   print "wa_name",row[7]   
   print "sort_name",row[8]
   print "nickname",row[9],"\n"



print "Operation done successfully";
conn.close()
