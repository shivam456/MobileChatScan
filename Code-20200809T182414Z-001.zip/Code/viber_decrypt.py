#!/usr/bin/python

import sqlite3

conn = sqlite3.connect('viber_data')
print "Opened database successfully";

cursor = conn.execute("SELECT photo,canonized_number from vibernumbers where canonized_number in (SELECT data2 from phonebookdata)")
for row in cursor:
   print "Photo ", row[0]
   print "Canonized Phone Number",row[1]
   print "\n\n"



print "Operation done successfully";
conn.close()
