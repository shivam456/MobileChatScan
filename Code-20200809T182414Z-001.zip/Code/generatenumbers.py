with open("numbers_to_Shivam.txt") as f:
    for line in f:
    	print line[:-1]+","+ "number" + line
        